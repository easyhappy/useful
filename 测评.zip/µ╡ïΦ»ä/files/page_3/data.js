﻿$axure.loadCurrentPage({
  "url":"page_3.html",
  "generationDate":new Date(1375070308854.5),
  "isCanvasEnabled":false,
  "variables":["OnLoadVariable"],
  "page":{
    "packageId":"19209366af8a4463bc9b942b64563348",
    "type":"Axure:Page",
    "name":"Page 3",
    "notes":{
},
    "style":{
      "baseStyle":"627587b6038d43cca051c114ac41ad32",
      "pageAlignment":"near",
      "fill":{
        "fillType":"solid",
        "color":0xFFFFFFFF},
      "image":null,
      "imageHorizontalAlignment":"near",
      "imageVerticalAlignment":"near",
      "imageRepeat":"",
      "sketchFactor":"0",
      "colorStyle":"appliedColor",
      "fontName":"Applied Font",
      "borderWidth":"0"},
    "adaptiveStyles":[],
    "interactionMap":{
},
    "diagram":{
      "objects":[]}},
  "masters":{
},
  "objectPaths":{
}});