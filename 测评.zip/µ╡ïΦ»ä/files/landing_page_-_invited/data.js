﻿$axure.loadCurrentPage({
  "url":"landing_page_-_invited.html",
  "generationDate":new Date(1375086598572.68),
  "isCanvasEnabled":false,
  "variables":["OnLoadVariable"],
  "page":{
    "packageId":"3456a371bc284f0bbf191d10d4a43616",
    "type":"Axure:Page",
    "name":"Landing Page - Invited",
    "notes":{
},
    "style":{
      "baseStyle":"627587b6038d43cca051c114ac41ad32",
      "pageAlignment":"near",
      "fill":{
        "fillType":"solid",
        "color":0xFFFFFFFF},
      "image":null,
      "imageHorizontalAlignment":"near",
      "imageVerticalAlignment":"near",
      "imageRepeat":"",
      "sketchFactor":"0",
      "colorStyle":"appliedColor",
      "fontName":"Applied Font",
      "borderWidth":"0"},
    "adaptiveStyles":[],
    "interactionMap":{
},
    "diagram":{
      "objects":[]}},
  "masters":{
},
  "objectPaths":{
}});