﻿$axure.loadCurrentPage({
  "url":"page_2.html",
  "generationDate":new Date(1375086598584.22),
  "isCanvasEnabled":false,
  "variables":["OnLoadVariable"],
  "page":{
    "packageId":"9524b26eebcf4539b9cf446dd08e217c",
    "type":"Axure:Page",
    "name":"Page 2",
    "notes":{
},
    "style":{
      "baseStyle":"627587b6038d43cca051c114ac41ad32",
      "pageAlignment":"near",
      "fill":{
        "fillType":"solid",
        "color":0xFFFFFFFF},
      "image":null,
      "imageHorizontalAlignment":"near",
      "imageVerticalAlignment":"near",
      "imageRepeat":"",
      "sketchFactor":"0",
      "colorStyle":"appliedColor",
      "fontName":"Applied Font",
      "borderWidth":"0"},
    "adaptiveStyles":[],
    "interactionMap":{
},
    "diagram":{
      "objects":[]}},
  "masters":{
},
  "objectPaths":{
}});